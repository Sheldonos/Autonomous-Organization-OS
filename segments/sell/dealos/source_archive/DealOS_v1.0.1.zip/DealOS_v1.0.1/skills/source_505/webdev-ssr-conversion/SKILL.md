---
name: webdev-ssr-conversion
description: Convert a client-only React 19 + Vite + Express + tRPC 11 SPA (the Manus "web-db-user" full-stack template) into a Server-Side Rendered (SSR) app so crawlers and social scrapers receive fully-populated first-paint HTML with correct per-route title and meta tags. Use when a project built on this template needs SEO, link-preview cards, or crawler-visible content, or when asked to "make the site SSR", "server-render", "fix SEO / prerender", or "make Googlebot see the content". Only for projects built on this template (wouter + @trpc/react-query + superjson, Express entry at server/_core). Do NOT use for Next.js/Remix/Astro apps, apps that already render on the server, or general SEO questions unrelated to this template.
---

# tRPC + React SSR Conversion

This skill converts the Manus full-stack template (React 19, Vite 7, Express 4, tRPC 11, wouter, TanStack Query 5, superjson) from a client-rendered SPA into an SSR app **without changing any page component or design**. SSR only changes *when/where* the HTML is produced — not what it looks like.

## When this applies

The template ships as an SPA: `client/index.html` loads `main.tsx`, which `createRoot().render()`s into `#root`. Crawlers that do not execute JS see an empty shell — bad for SEO and link previews. SSR fixes this by rendering the React tree to an HTML string on the server, with the data already fetched, then hydrating on the client.

Confirm the stack matches before starting: `renderToString`/`hydrateRoot` (react-dom 19), `wouter` routing, tRPC via `@trpc/react-query`, superjson transformer, Express entry at `server/_core/index.ts` that calls `setupVite` (dev) and `serveStatic` (prod) from `server/_core/vite.ts`.

## Mental model (read once, then follow the checklist)

1. **One tree, two entries.** Factor the app so the *same* `<App/>` renders on the server (`entry-server.tsx` → `renderToString`) and the client (`entry-client.tsx` → `hydrateRoot`). Providers (tRPC, QueryClient, Router) must wrap App identically in both, or hydration mismatches.

1. **Data must be in the cache before render.** `renderToString` is synchronous and does NOT wait for queries. So **prefetch** every query a route needs into a `QueryClient` first, `dehydrate()` it, embed it in the HTML, and let `HydrationBoundary` rehydrate it on the client so the first client render matches the server with no refetch flash.

1. **Prefetch runs in-process, not over HTTP.** Build a server-side tRPC **caller** (`appRouter.createCaller(ctx)`) so SSR calls procedures as plain function calls. This keeps `ctx.user` from the cookie without re-forwarding headers, avoids per-request loopback latency and self-load, and sidesteps middleware ordering hazards of the server calling its own HTTP endpoint.

1. **The server owns HTML.** Static file serving must NOT auto-serve `index.html`; Express catches all routes, renders, injects `<title>/<meta>` + serialized state into template placeholders, and returns it.

1. **Kill every browser-only access on the server render path.** `window`, `document`, `localStorage`, `sessionStorage`, `matchMedia` are undefined in Node. Any one on the render path throws and silently drops you to the empty shell. (`btoa` and `navigator` DO exist in Node ≥16/≥21 — they won't throw but return wrong/absent values, a hydration-mismatch hazard rather than a crash; the template's `getLoginUrl()` crash comes from `window.location.origin`, not `btoa`.)

1. **SSR alone is not SEO parity.** Crawlers and social scrapers also need og:/twitter: tags, canonical URLs, and *real* 404 status codes in the raw HTML/response. These are part of the conversion (steps 3 and 5), not an afterthought.

## Conversion checklist

Follow in order. `references/ssr-playbook.md` has the full, copy-adaptable code for every file; read it before editing. `references/pitfalls.md` lists the exact errors seen during a real conversion and their fixes — consult it whenever an SSR render falls back to the shell.

**Step 0 — enumerate and scope.** `grep -rn "<Route" client/src --include="*.tsx"` and classify every route public vs auth-gated. If the grep output has a variable-driven line (`path={r.path}` or similar), the routes live in a registry module — open it (often a plain `.ts`, so widen the follow-up grep: `grep -rn "path:" client/src --include="*.ts" --include="*.tsx"`) and treat registry entries PLUS any inline `<Route>`s as the one list. The prefetch map, Head.tsx titles, and the verify table must all be built from — and cross-checked against — this one list: a public route missing from the prefetch map ships as HTTP 404 (pitfalls §15). While you're at it, grep for `lazy(` on route components (pitfalls §13), `useInfiniteQuery` (playbook §4), and `useSuspenseQuery` (playbook §2 — unlike plain queries it fetches during render, so it can't just be left un-prefetched: on PUBLIC routes prefetch it or convert it to plain `useQuery`; on gated routes do neither — add a route-level `<Suspense>` instead). If the public surface is only a handful of marketing pages (SaaS-shaped app), say so in your plan: gated routes stay client-rendered by design (200 + noindex + default head), and the conversion effort should be weighed against that small surface.

1. **Template placeholders** (`client/index.html`):
  - Add `<!--app-head-->` inside `<head>` and wrap the mount node: `<div id="root"><!--app-html--></div>`. Point the module script at `entry-client.tsx`.
  - **Delete the existing static ****`<title>{{project_title}}</title>`**** AND any other static SEO tags ****`composeHtml`**** now owns** — static `<meta name="description">`, `og:*`, `twitter:*`, and `rel="canonical"`. `composeHtml` emits per-route versions, scrapers/crawlers resolve a duplicated `<title>`/`og:title` to the FIRST tag, and a duplicated `rel=canonical` makes Google ignore ALL canonical hints for the page (a leftover static canonical usually points at `/`, so every page silently loses its per-route canonical) — either way the per-route values are silently defeated. Keep non-SEO head content (favicon, fonts, analytics `%VITE_*%` script) untouched.
  - **Keep the template's analytics ****`<script>`** and `%VITE_*%` placeholders.
  - Set `<html lang>` to the site's content language (the template ships `lang="en"`).

1. **Split entries.** Create `client/src/entry-server.tsx` (exports `async render(url, prefetch)`) and `client/src/entry-client.tsx` (`hydrateRoot`, reads `window.__RQ_STATE__`). Keep provider order identical. Pass `ssrPath`/`ssrSearch` to wouter's `<Router>` on the server only, splitting `req.originalUrl` at the FIRST `?` yourself in `render()` (playbook §2) — relying on wouter's own `ssrPath` split mis-handles a bare trailing `?` (not split → NotFound body under a 200 head) and DROPS everything after a second `?` (server/client `useSearch` diverge → seeded-key mismatch, hydration refetch).

1. **Prefetch map.** Create `client/src/ssr/prefetch.ts`: a `prefetchForPath(url, queryClient, prefetch)` that matches the path, awaits the needed data, seeds it into the query cache under the **exact** tRPC query key (`getQueryKey(trpc.x.y, input, "query")`), and returns a `HeadMeta` (`title`, `description`, og: fields, `canonicalPath`, `notFound`). Rules:

   Also create `client/src/components/Head.tsx` (playbook §9) and mount it in `App`: it syncs `document.title` on client-side navigation (SSR only bakes the title into the initial HTML); dynamic detail pages call `useDocumentTitle(title)` once their data arrives. Multi-locale project? Read playbook §11 first (per-request locale, factored route tables, per-route lang/og:locale).
  - **`notFound`**** may only come from a genuine miss** (procedure returned null / threw `NOT_FOUND`) — never from a catch-all. A `.catch(() => null)` turns DB outages into 404 + noindex and gets real pages deindexed; rethrow non-miss errors into the shell fallback.
  - **Auth-gated routes (portal/admin) need an explicit branch in code** returning default head + `noindex: true` with no prefetch — otherwise they fall through to the 404 default. Same 200+noindex treatment for /cart and internal search results.
  - **The prefetch input must mirror what the component's ****`useQuery`**** actually produces for that URL** (the exact-key guardrail), independent of indexability. If the component derives a filter from the query string (`useSearch`), seed the ACTUAL filtered fetch under that exact input; `canonicalPath` still points at the bare path (filtered views stay non-indexed by default — add the params to `canonicalPath` only if the filtered view must be indexable in its own right). Prefetch the unfiltered list ONLY when the component ignores the URL params (filter is client-side state) — then the unfiltered input IS the component's input. Never seed unfiltered data under a filtered key (shows wrong content until refetch) or a filtered key the component never reads (skeleton body + wasted DB call). If serving the filtered fetch is impractical, skip seeding the list for that request (component client-fetches, same as the SPA).
  - **Pagination is the mandatory exception**: prefetch the REQUESTED page (`Number(page) || 1` — the input must match the component's types exactly) and self-canonicalize to the paged URL; canonicalizing page 2+ back to page 1 orphans the whole back catalog for non-JS crawlers (playbook §4).
  - **`useInfiniteQuery`**** needs the ****`"infinite"`**** key type and ****`{pages, pageParams}`**** shape** — seed per playbook §4, or leave that section client-fetched rather than seeding a wrong shape.

1. **In-process caller.** Create `server/_core/ssrCaller.ts`: `buildSsrPrefetch(req,res)` builds context via `createContext` and returns thin wrappers over `appRouter.createCaller(ctx).<procedure>`.

1. **Wire the server** (`server/_core/vite.ts`):
  - `composeHtml()` injects head tags (title, description, og:/twitter:, canonical — **HTML-escape every value**; they may come from the DB), app HTML, and `window.__RQ_STATE__ = superjson.serialize(state)` into the placeholders. Replacement values as **functions** (`.replace(ph, () => value)`), never strings, or `$`-sequences in content corrupt the page. Inject the state script into the template **before** splicing in app HTML.
  - **Set two env vars in the deployment environment (not just your local shell):** `CANONICAL_ORIGIN` (e.g. `https://example.com` ) — without it, canonical/og:url tags AND relative og:image absolutization are silently omitted site-wide (only a boot `console.warn` signals this); and `SITE_NAME` — feeds `og:site_name` and the prod-fallback default title (unset ⇒ the `og:site_name` tag is omitted entirely and the prod-fallback title degrades to the hardcoded `…site title…` placeholder — playbook §6). Keep `SITE_NAME` equal to the `SITE` constant in `prefetch.ts`/`Head.tsx`.
  - Respond `res.status(head.notFound ? 404 : 200)` and set **`Cache-Control: no-cache`**** on all SSR HTML** — the dehydrated state is per-user (cookie-derived `ctx.user`); a shared cache serving it across users is a data leak.
  - Before `express.static(dist, { index: false, redirect: false })`: 301-redirect explicit `/index.html` requests to `/`, and 301-normalize trailing slashes (`/news/` → `/news`) so duplicate-content URLs collapse without relying on canonical hints. `redirect: false` is required: serve-static's default directory 301 (`/assets` → `/assets/`; `dist/public/assets/` always exists) would ping-pong with the trailing-slash 301 into an infinite redirect loop — with it off, bare directory paths fall through to the SSR catch-all's real 404.
  - **Dev path**: replace the body of `setupVite`'s catch-all — retarget the template's nanoid cache-buster at `entry-client.tsx`, call `vite.transformIndexHtml` (NOT optional: it injects the Manus runtime + debug-collector scripts), add the `?direct` blocking-CSS link (step 10), then `vite.ssrLoadModule("/src/entry-server.tsx")`, render, respond; on error `vite.ssrFixStacktrace(e)` and `next(e)` so dev surfaces the failure.
  - **Prod path**: read the built template (`dist/public/index.html`), `import` the prebuilt SSR bundle, render, respond. Wrap in try/catch; the fallback serves the shell at 200 **with default head tags** (an empty head makes crawlers index an untitled thin page) — and monitor/alert on the `[SSR] render failed` log line, because this failure is invisible to human QA.

1. **SSR-safety fixes.** Guard every browser global behind `typeof window === "undefined"` on the render path:
  - The template's `getLoginUrl()` (`client/src/const.ts`, uses `window.location.origin`), `useAuth` (writes `localStorage` inside `useMemo`, and evaluates `getLoginUrl()` as a default parameter on every call), and **`DashboardLayout`** (reads `localStorage` in a `useState` initializer — crashes every gated-route render). Sweep the FULL hazard set, not just storage: `grep -rnE "localStorage|sessionStorage|matchMedia|\bwindow\.|\bdocument\.|\bnavigator\." client/src --include="*.tsx" --include="*.ts"` (hooks/stores are usually `.ts`). The three-token storage-only grep misses bare `window.location`/`window.innerWidth`/`document.*` in evolved code — the template's own `getLoginUrl()` (const.ts) reads `window.location.origin` on the render path yet is caught only because the skill names it. Triage: hits inside `useState`/`useMemo` initializers, default parameter values, module scope, and JSX expressions are render-path hazards; hits inside `useEffect` bodies and event handlers are safe (the broad sweep adds ~25 mostly-benign hits on the fresh template — e.g. `useMobile.tsx`'s `window.matchMedia`, which the storage grep already surfaced and which reads only inside an effect).
  - **Check first whether ****`getLoginUrl()`**** appears in JSX** (e.g. `<a href={getLoginUrl()}>`): if so, an SSR placeholder return value leaks into the rendered HTML — a bare `typeof window` ternary on the href does NOT self-heal (see the attribute-mismatch note below); convert those to `onClick` imperative navigation, or use `const [href,setHref]=useState(placeholder); useEffect(()=>setHref(getLoginUrl()),[])`.
  - **Guards must swap behavior, never rendered output**: `typeof window` ternaries in JSX and `localStorage`/theme-driven output (cart badge, dark-mode toggle icon) cause React 19 hydration mismatches — render the server-safe default on BOTH the server and the client's first render, then load the stored value in `useEffect` (pitfalls §12). Note the two mismatch modes differ (pitfalls §12): a text/element-structure diff is logged and the client value wins; an **attribute-value** diff (className/href/style) is NOT patched — the server value sticks silently forever in prod — so the effect-swap pattern is mandatory, not optional.
  - `ThemeContext` is SSR-safe **as shipped** (localStorage is only read when `switchable` is enabled; `document` only in `useEffect`). Only if the project enabled `switchable`: (a) the inline pre-paint `<head>` script fixes the CSS flash on `<html>`; (b) SEPARATELY, the guarded `useState` initializer must still return the server-safe default on the client's first render too (NOT seed from `document.documentElement`'s class) and swap the real theme in `useEffect` — otherwise any theme-conditional element inside `#root` (the template's own `{theme==="light"?<Moon/>:<Sun/>}` toggle) is a hydration mismatch (pitfalls §12, "browser-persisted state rendered directly").
  - For SSR-hostile deps (`streamdown`; maps/editors/charts that touch `window` at module scope): **grep for every import first** (`grep -rn "streamdown" client/src`) — the fresh template's grep hits public `Home.tsx` (in the graph from App — this is what crashes SSR) and `AIChatBox` (reachable only via the *unrouted* ComponentShowcase demo, so out of the graph on a fresh template; back in it the moment a project routes/reuses it). What matters is the **static import graph reachable from App**, not which route renders the component. Do NOT replace deps app-wide; handle each reachable import via the decision rule + options in playbook §10 (for a loader-hostile-only dep like streamdown, `ssr.noExternal` keeps it rendering unchanged — playbook §10 option 0). If the error stack points into `node_modules` for a `window`/`document` access at import time, guards can't fix it — graph exclusion only (pitfalls §1b).

1. **Two-config build.** The main `vite.config.ts` sets `root: client/`, which doubles the `--ssr` entry path. Add a dedicated `vite.config.ssr.ts` (project root as base, `mode:"production"`, `define process.env.NODE_ENV=production`, `build.ssr = entry-server.tsx`, `outDir dist/server-ssr`). **Copy every ****`resolve.alias`**** from the project's ****`vite.config.ts`** (the template has `@`, `@shared`, AND `@assets` — a missing alias fails only the SSR build). Plugins: omit only the template's own dev-tooling (jsxLoc/manus-runtime/debug-collector), but **copy every project-added plugin that transforms app source or assets** (svgr, glsl/wasm, imagetools — playbook §7). The `mode`/`define` here are defense-in-depth only: Vite keeps a pre-existing `NODE_ENV` (and `@vitejs/plugin-react` follows it), so they do NOT stop the `jsxDEV is not a function` crash if the shell has `NODE_ENV=development` — the `NODE_ENV=production` prefix on the build command (step 8) is what actually controls the JSX runtime; never skip it. (`ssr.noExternal` also lives here — see step 6/playbook §7/pitfalls §14 for when it's needed.)

1. **Build script.** `NODE_ENV=production` must prefix the **whole** chain: `NODE_ENV=production vite build && NODE_ENV=production vite build --config vite.config.ssr.ts && esbuild ...`. A development env leaks into the client leg silently (dev React in the prod bundle); it breaks the SSR leg loudly.

1. **Prod entry path.** In `serveStatic`, resolve the SSR bundle at `dist/server-ssr/entry-server.js` relative to `import.meta.dirname` (which is `dist/` in the bundled prod server), not `../server-ssr`.

1. **Kill the DEV-only unstyled flash.** In the dev SSR handler (after `vite.transformIndexHtml`), inject a render-blocking `<link rel="stylesheet" href="/src/index.css?direct">`. In dev Vite serves CSS via a JS module (HMR), so the SSR'd HTML is unstyled until hydration; the `?direct` variant is real `text/css` and blocks first paint like prod does. Prod is unaffected (built hashed stylesheet). Do NOT inline the full CSS via `?inline` — it bloats every dev response. See `references/pitfalls.md` §8.

1. **Verify with crawlers.** Build, then start prod with the env the head tags depend on and a pinned port: `CANONICAL_ORIGIN=http://localhost:4101 SITE_NAME="…" PORT=4101 NODE_ENV=production node dist/index.js` (a localhost origin satisfies the script's presence/substring checks; a plain `node dist/index.js` listens on 3000 while the verifier defaults to `BASE=4101`, so the first run all-curl-errors — PORT must match BASE, and the template's `findAvailablePort` falls back to the next free port when busy — logging `Port X is busy, using port Y instead` — so confirm the actual port from the listen log ). **Copy ****`scripts/verify-ssr.sh`**** from this skill into the project's ****`scripts/`**** directory and edit the route table there** (never edit the bundled copy): one row per route **class** (home, list page 1 AND page ≥2, ONE per detail type, plus content edge cases like a unicode slug; **plus one gated row** — flags `nocanon,noindex` — if the app has auth-gated routes, and one `check_301` per redirect class; keep the bundled `/assets` static-directory guard row) — on content-heavy sites sample rather than enumerating every URL, and refresh record-derived needles when content churns. Each content needle must be **body-only text** that does not appear in the title/description; flag detail rows that have a share image with `ogimage`. Run it (`BASE=http://localhost:4101 bash scripts/verify-ssr.sh` ) — it asserts HTTP 200, body content inside `#root`, a single route-specific `<title>` / `og:title` / canonical (no leftover duplicates), the og:title value (plus presence of og:description/twitter:card/canonical/og:url), an absolute og:image URL on `ogimage` rows, the 200+noindex contract on gated rows AND the absence of noindex on indexable rows, non-empty dehydrated state, redirect targets on `check_301` rows, and real 404s (with noindex) for bogus slugs; it exits non-zero on any failure. (On the template's own prod HTML — which carries a large inline runtime script — the script runs in ~1-2s; if it instead takes minutes at 99% CPU you are on an older copy whose bash-glob body-slice is quadratic — re-copy this version.) If a browser is available, also screenshot a couple of pages (or headless-load them and check the console has no hydration errors) to confirm hydration still works; skip if the environment has no browser.

## Out of scope (name these in your summary — do not silently skip)

Cheap follow-ups this conversion does NOT include, worth offering to the user:

- **`/sitemap.xml`** — an Express route built from the same in-process caller's slug lists (~20 lines).

- **`robots.txt`** in `client/public/` with a `Sitemap:` line.

- **Structured data (JSON-LD), matched to the domain** — Product+Offer on product pages (price/availability rich results; usually the highest-ROI follow-up for storefronts), NewsArticle/BlogPosting on article pages, Organization/LocalBusiness site-wide.

- **`/rss.xml`** for publication-shaped sites — an Express route from the same caller's recent-posts list (~30 lines), plus a `<link rel="alternate" type="application/rss+xml">` head tag.

## Quick reference: what each new/edited file does

| File | Role |
| --- | --- |
| `client/index.html` | Adds `<!--app-head-->`, `<!--app-html-->`; script → `entry-client.tsx`; static `<title>` deleted; analytics kept; `lang` set |
| `client/src/entry-server.tsx` | `render(url, prefetch)` → prefetch, `renderToString`, return `{html, dehydratedState, head}` |
| `client/src/entry-client.tsx` | `hydrateRoot`, deserialize `window.__RQ_STATE__`, `HydrationBoundary`; keeps template QueryClient defaults + adds `staleTime` only |
| `client/src/ssr/prefetch.ts` | Path → queries to prefetch (+ correct query keys; pagination/infinite variants) → `HeadMeta` (notFound/noindex/ogImage); narrow notFound; explicit auth-gated branch |
| `client/src/components/Head.tsx` | Client-side `document.title` sync on route change |
| `server/_core/ssrCaller.ts` | In-process tRPC caller for prefetch (keeps `ctx.user`) |
| `server/_core/vite.ts` | `composeHtml` (escaped head + og:/canonical, function-form replace, 404 status, Cache-Control) + dev (`ssrLoadModule` + `transformIndexHtml`) and prod (prebuilt import, default-head fallback) wiring; `/index.html` + trailing-slash 301s; `static({index:false,redirect:false})`; dev `?direct` CSS. Reads `CANONICAL_ORIGIN` (canonical/og:url/og:image) + `SITE_NAME` (og:site_name/fallback title) from env |
| `vite.config.ssr.ts` | Dedicated SSR build (root base, production mode, `dist/server-ssr`, ALL aliases copied) |
| `client/src/const.ts`, `useAuth`, `DashboardLayout` | `typeof window` guards (`ThemeContext` only if `switchable`) |
| (markdown handling) | Keep `streamdown` — grep ALL imports; handle every hit reachable from App per the content-role rule (`ssr.noExternal` for a loader-hostile-only dep / lazy-load / client-gate / route-local replacement — playbook §10) |

## Bundled resources

- `references/ssr-playbook.md` — full annotated source for every file above, plus the exact `package.json` build script and `vite.config.ssr.ts`. Read before writing code.

- `references/pitfalls.md` — the concrete failures from a real conversion (`window is not defined` — app code AND dep-module-scope variants, `jsxDEV is not a function`, doubled SSR entry path, prod bundle path, `.css` extension error, hydration double-fetch, index.html served past static, dev unstyled-flash, theme flash, `$`-pattern content corruption, stored XSS via head tags, transient-error-as-404, hydration mismatch from nondeterministic render, lazy-route spinners, CJS/ESM interop, new-route-404-after-conversion, crawl-burst load, and the SEO-parity checklist) with root cause and fix. Read when a render falls back to the shell or the build fails.

- `scripts/verify-ssr.sh` — crawler curl harness asserting status codes, body content inside `#root`, `<title>`, og:title value (+ og/canonical presence, absolute og:image on flagged rows), dehydrated state, and 404+noindex; exits non-zero on failure. **Copy it into the project's ****`scripts/`**** dir and edit the route table there.**

## Guardrails

- Do NOT restyle or "fix" anything based on SSR output alone — SSR must be visually identical to the SPA. If it differs, it is a hydration bug, not a design task.

- Do NOT change app-wide behavior as a side effect: keep the client QueryClient's template defaults (add `staleTime` only — required to stop hydrate-then-refetch double fetching), and never swap shared dependencies (markdown renderer, sanitizers) globally when a route-local fix suffices.

- HTML-escape every dynamic value interpolated into head tags — titles/excerpts from the DB are untrusted input; unescaped interpolation is stored XSS.

- Never prefetch auth-GATED route content or other users' private data into HTML; gate those routes to default head + noindex + client-only fetch. The requester's own `auth.me` MAY be seeded to remove the logged-out→logged-in header flip after hydration — but that permanently pins SSR HTML to private/no-cache; if you skip it (the default), the flash is expected behavior worth mentioning to the user. Prefetched procedures on public routes must be viewer-independent — a public list that branches on `ctx.user` (likedByMe etc.) should split the viewer part into a separate client-fetched procedure (playbook §5).

- Never return `notFound` from a catch-all error handler — only a genuine miss (null / `NOT_FOUND`) may 404; transient backend errors must degrade to the 200 shell, or crawlers deindex real pages.

- Default `Cache-Control: no-cache` on SSR HTML. Only allow shared/CDN caching after verifying every prefetched procedure ignores `ctx.user`, and never cache cookie-varying HTML without `Vary: Cookie`.

- Keep the shell fallback in the prod catch block (with default head tags); a render exception should degrade to a working SPA, never a 500. Alert on the `[SSR] render failed` log — humans won't notice this failure. **Caveat:** `renderToString` only throws (reaching the catch) for errors thrown OUTSIDE every Suspense boundary — an error thrown INSIDE one is silently baked into that boundary's fallback HTML (200, no log, no console output), so the alert does NOT cover Suspense-wrapped subtrees that the playbook §10 / pitfalls §13 patterns add. The `verify-ssr.sh` content needles are the only automated detection there — re-run it after content changes, not just code changes.

- Query keys used in prefetch MUST match what components use (`getQueryKey(proc, input, "query")` with the *same* input object shape and the same decoding of URL-derived values), or the client refetches and you get a flash.

- Re-run `scripts/verify-ssr.sh` after any change to routing, providers, or data fetching.

---

## webdev-voice-transcription

